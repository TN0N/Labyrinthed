export class Light {

    constructor({
        ambient = 0,
    } = {}) {
        this.ambient = ambient;
    }

}
